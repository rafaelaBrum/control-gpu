"""pytorchexample: A Flower / PyTorch app."""

from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord, Array
from flwr.serverapp import Grid, ServerApp
from strategy import CustomEmpty
from flwr.serverapp.strategy import FedAvg
import numpy as np


# Create ServerApp
app = ServerApp()


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main entry point for the ServerApp."""

    # Read run config
    fraction_evaluate: float = context.run_config["fraction-evaluate"]
    num_rounds: int = context.run_config["num-server-rounds"]
    lr: float = context.run_config["learning-rate"]
    length_parameters: int = context.run_config["length-parameters"]
    file: str = context.run_config["file"]

    # Initialize FedAvg strategy
    strategy = CustomEmpty()

    
    arr1 = np.random.randn(length_parameters)
    record = ArrayRecord([arr1])

    # Start strategy, run FedAvg for `num_rounds`
    result = strategy.start(
        grid=grid,
        initial_arrays=record,
        train_config=ConfigRecord({"lr": lr, "param": length_parameters}),
        num_rounds=1,
        file=file
    )

    if context.run_config["save-model"]:
        # Save final model to disk
        print("\nSaving final model to disk...")
