"""pytorchexample: A Flower / PyTorch app."""

from flwr.app import ArrayRecord, Context, Message, MetricRecord, RecordDict
from flwr.clientapp import ClientApp
import numpy as np

# Flower ClientApp
app = ClientApp()


@app.train()
def train(msg: Message, context: Context):
    """Train the model on local data."""
    metrics = {
        "train_loss": 0.0,
        "num-examples": 1,
    }
    content = RecordDict({"arrays": msg.content["arrays"], "metrics": MetricRecord({"num-examples":1})})
    return Message(content=content, reply_to=msg)


@app.evaluate()
def evaluate(msg: Message, context: Context):
    """Evaluate the model on local data."""

    metrics = {
        "eval_loss": 0.0,
        "eval_acc": 0.0,
        "num-examples": 1,
        "num-examples": 1,
        "num-examples": 1,
        "num-examples": 1,
        "num-examples": 1,
        "num-examples": 1,
        "num-examples": 1,
    }
    metric_record = MetricRecord(metrics)
    content = RecordDict({"metrics": metric_record})
    return Message(content=content, reply_to=msg)
