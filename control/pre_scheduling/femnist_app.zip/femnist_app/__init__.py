from .model_daemon import Model
from .cnn import ClientModel