from .model_daemon import Model
from .stacked_lstm import ClientModel