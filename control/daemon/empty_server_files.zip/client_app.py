"""pytorchexample: A Flower / PyTorch app."""

from flwr.app import ArrayRecord, Context, Message, MetricRecord, RecordDict
from flwr.clientapp import ClientApp
import numpy as np

# Flower ClientApp
app = ClientApp()


@app.train()
def train(msg: Message, context: Context):
    """Train the model on local data."""
    
    metrics = {
        "train_loss": 0.0,
        "num-examples": 1,
    }
    metric_record = MetricRecord(metrics)

    arr1 = np.random.randn(3, 3)
    arr2 = np.random.randn(2, 2)
    record = ArrayRecord([arr1, arr2])

    content = RecordDict({"arrays": record, "metrics": metric_record})
    return Message(content=content, reply_to=msg)


@app.evaluate()
def evaluate(msg: Message, context: Context):
    """Evaluate the model on local data."""

    metrics = {
        "eval_loss": 0.0,
        "eval_acc": 0.0,
        "num-examples": 1,
    }

    parameters = msg.content["arrays"].to_numpy_ndarrays()

    if context.run_config['client-checkpoint']:
        global_epoch = int(msg.content.config_records['config']['server-round'])
        if global_epoch > 1:
            print(f"Removing old round-{global_epoch-1}-weights.npz saved file")
            try:
                os.remove(f"round-{global_epoch-1}-weights.npz")
            except Exception as e:
                print("ERROR:", e)
        print(f"Saving round {global_epoch} aggregated_ndarrays...")
        checkpoint_file = f"round-{global_epoch}-weights.npz"
        np.savez(checkpoint_file, *parameters)
        with open("checkpoint.txt", "a") as file:
            file.write(f"\n{checkpoint_file}")

    metric_record = MetricRecord(metrics)
    content = RecordDict({"metrics": metric_record})
    return Message(content=content, reply_to=msg)
