"""pytorchexample: A Flower / PyTorch app."""

from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord, Array
from flwr.serverapp import Grid, ServerApp
# from modules.strategy import CustomEmpty
from flwr.serverapp.strategy import FedAvg
import numpy as np


# Create ServerApp
app = ServerApp()


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main entry point for the ServerApp."""

    # Read run config
    fraction_evaluate: float = context.run_config["fraction-evaluate"]
    num_rounds: int = context.run_config["num-server-rounds"]
    lr: float = context.run_config["learning-rate"]

    # Initialize FedAvg strategy
    # strategy = CustomEmpty()
    strategy = FedAvg(fraction_evaluate=fraction_evaluate)

    
    arr1 = np.random.randn(3, 3)
    arr2 = np.random.randn(2, 2)
    record = ArrayRecord([arr1, arr2])

    # Start strategy, run FedAvg for `num_rounds`
    result = strategy.start(
        grid=grid,
        initial_arrays=record,
        train_config=ConfigRecord({"lr": lr}),
        num_rounds=num_rounds,
        evaluate_fn=global_evaluate,
    )

    if context.run_config["save-model"]:
        # Save final model to disk
        print("\nSaving final model to disk...")


def global_evaluate(server_round: int, arrays: ArrayRecord) -> MetricRecord:
    """Evaluate model on central data."""

    # Return the evaluation metrics
    return MetricRecord({"accuracy": 0.0, "loss": 0.0})
