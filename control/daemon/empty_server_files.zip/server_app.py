"""pytorchexample: A Flower / PyTorch app."""

from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord, Array
from flwr.serverapp import Grid, ServerApp
# from modules.strategy import CustomEmpty
from flwr.serverapp.strategy import FedAvg
import numpy as np

import os


# Create ServerApp
app = ServerApp()


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main entry point for the ServerApp."""

    # Read run config
    num_rounds: int = context.run_config["num-server-rounds"]
    lr: float = context.run_config["learning-rate"]
    checkpoint: bool = context.run_config["server-checkpoint"]
    frequency_ckpt: int = context.run_config["frequency-ckpt"]
    restore_ckpt: bool = context.run_config["restore-ckpt"]

    # Initialize FedAvg strategy
    strategy = FedAvg()

    train_config = ConfigRecord({"lr": lr})

    if restore_ckpt:
        while not os.path.exists('weights.npz'):
                continue
        file = 'weights.npz'
        aux_data = np.load(file)
        print(aux_data)
        aux_list = []
        for file in aux_data.files:
            aux_list.append(aux_data[file])
        print(aux_list)
        record = ArrayRecord(aux_list)
    else:            
        arr1 = np.random.randn(3, 3)
        arr2 = np.random.randn(2, 2)
        record = ArrayRecord([arr1, arr2])
    
    # Start strategy, run FedAvg for `num_rounds`
    if checkpoint:
        result = strategy.start(
            grid=grid,
            initial_arrays=record,
            train_config=train_config,
            num_rounds=num_rounds,
            evaluate_fn=get_evaluate_fn(frequency_ckpt, num_rounds),
        )
    else:
        result = strategy.start(
            grid=grid,
            initial_arrays=record,
            train_config=train_config,
            num_rounds=num_rounds,
        )


def get_evaluate_fn(frequency_ckpt, total_rounds):
    def evaluate(server_round: int, arrays: ArrayRecord) -> MetricRecord:
        # Save model every `save_every_round` round and for the last round
        if server_round != 0 and (
            server_round == total_rounds or server_round % frequency_ckpt == 0
        ):
            aggregated_ndarrays = arrays.to_numpy_ndarrays()
            print(f"Saving round {server_round} aggregated_ndarrays...")
            checkpoint_file = f"round-{server_round}-weights.npz"
            np.savez(checkpoint_file, *aggregated_ndarrays)
            with open("checkpoints.txt", "a") as file:
                file.write(f"\n{checkpoint_file}")

        return MetricRecord()

    return evaluate