# Copyright 2020 Adap GmbH. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Federating: Fast and Slow (v1)."""


from logging import DEBUG, INFO, WARNING
from typing import Callable, Dict, List, Optional, Tuple, cast

import numpy as np

from flwr.common import (
    EvaluateRes,
    FitIns,
    FitRes,
    MetricsAggregationFn,
    Parameters,
    Scalar,
    NDArrays,
    parameters_to_ndarrays,
    ndarrays_to_parameters,
)
from flwr.common.logger import log
from flwr.server.client_manager import ClientManager
from flwr.server.client_proxy import ClientProxy

from flwr.server.strategy.aggregate import aggregate, weighted_loss_avg
from fast_and_slow_strategy import (
    is_fast_round,
    next_timeout,
    normalize_and_sample,
    timeout_candidates,
)
from fedavg_strategy import FedAvg, weighted_metrics_avg

E = 0.001
E_TIMEOUT = 0.0001
WAIT_TIMEOUT = 600


class FedFSv1(FedAvg):
    """Strategy implementation which alternates between sampling fast and slow
    cients."""

    # pylint: disable=too-many-arguments,too-many-instance-attributes,too-many-locals
    def __init__(
        self,
        fraction_fit: float = 0.1,
        fraction_eval: float = 0.1,
        min_fit_clients: int = 1,
        min_eval_clients: int = 1,
        min_available_clients: int = 1,
        eval_fn: Optional[
            Callable[[NDArrays], Optional[Tuple[float, Dict[str, Scalar]]]]
        ] = None,
        min_completion_rate_fit: float = 0.5,
        min_completion_rate_evaluate: float = 0.5,
        on_fit_config_fn: Optional[Callable[[int], Dict[str, Scalar]]] = None,
        on_evaluate_config_fn: Optional[Callable[[int], Dict[str, Scalar]]] = None,
        dynamic_timeout_percentile: float = 0.8,
        r_fast: int = 1,
        r_slow: int = 1,
        t_max: int = 10,
        use_past_contributions: bool = False,
        initial_parameters: Optional[Parameters] = None,
        fit_metrics_aggregation_fn: Optional[MetricsAggregationFn] = None,
        evaluate_metrics_aggregation_fn: Optional[MetricsAggregationFn] = None,
    ) -> None:
        super().__init__(
            fraction_fit=fraction_fit,
            fraction_eval=fraction_eval,
            min_fit_clients=min_fit_clients,
            min_eval_clients=min_eval_clients,
            min_available_clients=min_available_clients,
            eval_fn=eval_fn,
            on_fit_config_fn=on_fit_config_fn,
            on_evaluate_config_fn=on_evaluate_config_fn,
            initial_parameters=initial_parameters,
            fit_metrics_aggregation_fn=fit_metrics_aggregation_fn,
            evaluate_metrics_aggregation_fn=evaluate_metrics_aggregation_fn,
        )
        self.min_completion_rate_fit = min_completion_rate_fit
        self.min_completion_rate_evaluate = min_completion_rate_evaluate
        self.dynamic_timeout_percentile = dynamic_timeout_percentile
        self.r_fast = r_fast
        self.r_slow = r_slow
        self.t_max = t_max
        self.use_past_contributions = use_past_contributions
        self.contributions: Dict[str, List[Tuple[int, int, int]]] = {}
        self.durations: List[Tuple[str, float, int, int]] = []
        self.fit_metrics_aggregation_fn = fit_metrics_aggregation_fn
        self.evaluate_metrics_aggregation_fn = evaluate_metrics_aggregation_fn

        if self.fit_metrics_aggregation_fn is None:
            self.fit_metrics_aggregation_fn = weighted_metrics_avg

        if self.evaluate_metrics_aggregation_fn is None:
            self.evaluate_metrics_aggregation_fn = weighted_metrics_avg

    def __repr__(self) -> str:
        rep = f"FedFSv1(dynamic_timeout_percentile={self.dynamic_timeout_percentile}, "
        rep += f"r_fast={self.r_fast}, r_slow={self.r_slow}, t_max={self.t_max})"
        return rep

    # pylint: disable=too-many-locals
    def configure_fit(
        self, rnd: int, parameters: Parameters, client_manager: ClientManager
    ) -> List[Tuple[ClientProxy, FitIns]]:
        """Configure the next round of training."""

        # Block until `min_num_clients` are available
        sample_size, min_num_clients = self.num_fit_clients(
            client_manager.num_available()
        )
        success = client_manager.wait_for(
            num_clients=min_num_clients, timeout=WAIT_TIMEOUT
        )
        if not success:
            # Do not continue if not enough clients are available
            log(
                INFO,
                "FedFS: not enough clients available after timeout %s",
                WAIT_TIMEOUT,
            )
            return []

        # Sample clients
        if rnd == 1:
            # Sample with 1/k in the first round
            log(
                DEBUG,
                "FedFS round %s, sample %s clients with 1/k",
                str(rnd),
                str(sample_size),
            )
            clients = self._one_over_k_sampling(
                sample_size=sample_size, client_manager=client_manager
            )
        else:
            fast_round = is_fast_round(rnd - 1, r_fast=self.r_fast, r_slow=self.r_slow)
            log(
                DEBUG,
                "FedFS round %s, sample %s clients, fast_round %s",
                str(rnd),
                str(sample_size),
                str(fast_round),
            )
            clients = self._fs_based_sampling(
                sample_size=sample_size,
                client_manager=client_manager,
                fast_round=fast_round,
            )

        # Prepare parameters and config
        config = {}
        if self.on_fit_config_fn is not None:
            # Use custom fit config function if provided
            config = self.on_fit_config_fn(rnd)

        # Set timeout for this round
        if self.durations:
            candidates = timeout_candidates(
                durations=self.durations,
                max_timeout=self.t_max,
            )
            timeout = next_timeout(
                candidates=candidates,
                percentile=self.dynamic_timeout_percentile,
            )
            config["timeout"] = str(timeout)
        else:
            # Initial round has not past durations, use max_timeout
            config["timeout"] = str(self.t_max)

        # Fit instructions
        fit_ins = FitIns(parameters, config)

        # Return client/config pairs
        return [(client, fit_ins) for client in clients]

    def _one_over_k_sampling(
        self, sample_size: int, client_manager: ClientManager
    ) -> List[ClientProxy]:
        """Sample clients with probability 1/k."""
        sample_size, min_num_clients = self.num_fit_clients(
            client_manager.num_available()
        )
        clients = client_manager.sample(
            num_clients=sample_size, min_num_clients=min_num_clients
        )
        return clients

    def _fs_based_sampling(
        self, sample_size: int, client_manager: ClientManager, fast_round: bool
    ) -> List[ClientProxy]:
        """Sample clients with 1/k * c/m in fast rounds and 1 - c/m in slow rounds."""
        all_clients: Dict[str, ClientProxy] = client_manager.all()
        k = len(all_clients)
        cid_idx: Dict[int, str] = {}
        raw: List[float] = []
        for idx, (cid, _) in enumerate(all_clients.items()):
            cid_idx[idx] = cid

            if cid in self.contributions:
                # Previously selected clients
                contribs: List[Tuple[int, int, int]] = self.contributions[cid]

                # pylint: disable=invalid-name
                if self.use_past_contributions:
                    cs = [c for _, c, _ in contribs]
                    ms = [m for _, _, m in contribs]
                    c_over_m = sum(cs) / sum(ms)
                else:
                    _, c, m = contribs[-1]
                    c_over_m = c / m
                # pylint: enable-msg=invalid-name

                if fast_round:
                    importance = (1 / k) * c_over_m + E
                else:
                    importance = 1 - c_over_m + E
            else:
                # Previously unselected clients
                if fast_round:
                    importance = 1 / k
                else:
                    importance = 1
            raw.append(importance)

        log(
            DEBUG,
            "FedFS _fs_based_sampling, sample %s clients, raw %s",
            str(sample_size),
            str(raw),
        )

        return normalize_and_sample(
            all_clients=all_clients,
            cid_idx=cid_idx,
            raw=np.array(raw),
            sample_size=sample_size,
            use_softmax=False,
        )

    def aggregate_fit(
        self,
        rnd: int,
        results: List[Tuple[ClientProxy, FitRes]],
        failures: List[BaseException],
    ) -> Tuple[Optional[Parameters], Dict[str, Scalar]]:
        """Aggregate fit results using weighted average."""
        if not results:
            return None, {}

        # Check if enough results are available
        completion_rate = len(results) / (len(results) + len(failures))
        if completion_rate < self.min_completion_rate_fit:
            # Not enough results for aggregation
            return None, {}

        # Convert results
        weights_results = [
            (parameters_to_ndarrays(fit_res.parameters), fit_res.num_examples)
            for client, fit_res in results
        ]
        weights_prime = aggregate(weights_results)

        # Track contributions to the global model
        for client, fit_res in results:
            cid = client.cid

            assert "num_examples_ceil" in fit_res.metrics
            num_examples_ceil: int = cast(int, fit_res.metrics["num_examples_ceil"])

            contribution: Tuple[int, int, int] = (
                rnd,
                fit_res.num_examples,
                num_examples_ceil,
            )
            if cid not in self.contributions:
                self.contributions[cid] = []
            self.contributions[cid].append(contribution)

        self.durations = []
        for client, fit_res in results:

            assert "fit_duration" in fit_res.metrics
            fit_duration: float = cast(float, fit_res.metrics["fit_duration"])

            assert "num_examples_ceil" in fit_res.metrics
            num_examples_ceil = cast(int, fit_res.metrics["num_examples_ceil"])

            cid_duration = (
                client.cid,
                fit_duration,
                fit_res.num_examples,
                num_examples_ceil,
            )
            self.durations.append(cid_duration)

        parameters_aggregated = ndarrays_to_parameters(weights_prime)

        # Aggregate custom metrics if aggregation fn was provided
        metrics_aggregated = {}
        if self.fit_metrics_aggregation_fn:
            fit_metrics = [(res.num_examples, res.metrics) for _, res in results]
            metrics_aggregated = self.fit_metrics_aggregation_fn(fit_metrics)
        elif rnd == 1:
            log(WARNING, "No fit_metrics_aggregation_fn provided")

        return parameters_aggregated, metrics_aggregated

    def aggregate_evaluate(
        self,
        rnd: int,
        results: List[Tuple[ClientProxy, EvaluateRes]],
        failures: List[BaseException],
    ) -> Tuple[Optional[float], Dict[str, Scalar]]:
        """Aggregate evaluation losses using weighted average."""
        print("results", results)
        if not results:
            return None, {}

        # Check if enough results are available
        completion_rate = len(results) / (len(results) + len(failures))
        if completion_rate < self.min_completion_rate_evaluate:
            # Not enough results for aggregation
            return None, {}

        # Aggregate loss
        loss_aggregated = weighted_loss_avg(
            [
                (evaluate_res.num_examples, evaluate_res.loss)
                for _, evaluate_res in results
            ]
        )

        # Aggregate custom metrics if aggregation fn was provided
        metrics_aggregated = {}
        if self.evaluate_metrics_aggregation_fn:
            eval_metrics = [(res.num_examples, res.metrics) for _, res in results]
            metrics_aggregated = self.evaluate_metrics_aggregation_fn(eval_metrics)
        elif rnd == 1:
            log(WARNING, "No evaluate_metrics_aggregation_fn provided")

        print("loss_aggregated", loss_aggregated)
        print("metrics_aggregated", metrics_aggregated)

        return loss_aggregated, metrics_aggregated
